#!/usr/bin/python3

def est_symetrique(matrice):
  ...

def test_est_symetrique():
  print('Test de la fonction est_symetrique')
  assert est_symetrique([[8]]), 'erreur 1'
  assert not est_symetrique([[1,3],[2,1]]), 'erreur 2'
  assert est_symetrique([[1,3],[3,2]]), 'erreur 3'
  assert est_symetrique([[1,2,3,4],[2,3,4,1],[3,4,1,2],[4,1,2,3]]), 'erreur 4'
  assert not est_symetrique([[7,1,2],[1,7,2],[7,2,1]]), 'erreur 5'
  assert not est_symetrique([[7,1,2],[1,7],[7,2,1]]), 'erreur 6'
  assert not est_symetrique([[1, 6661]]), 'erreur 7'
  print('  OK')


test_est_symetrique()
