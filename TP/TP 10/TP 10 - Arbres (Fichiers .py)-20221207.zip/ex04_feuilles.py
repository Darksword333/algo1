#!/usr/bin/python3

# FONCTIONS DE BASE
def creer_arbre_vide():
  return None

def creer_arbre(r,g,d):
  return r,g,d

def racine(arbre):
  return arbre[0]

def gauche(arbre):
  return arbre[1]

def droite(arbre):
  return arbre[2]

def est_vide(arbre):
  return arbre==None

# EXERCICE
def nombre_feuilles(arbre):
  ...

def test_nombre_feuilles():
  print('Test de la fonction nombre_feuilles')
  assert nombre_feuilles(None)==0
  assert nombre_feuilles((5,None,None))==1
  assert nombre_feuilles((2,(6,None,None),None))==1
  assert nombre_feuilles((1,None,(4,None,None)))==1
  # ┌─ 0 ─┐
  # 2     7
  assert nombre_feuilles((0,(2,None,None),(7,None,None)))==2
  # 0 ──────────┐
  #       ┌──── 1
  #    ┌─ 2 ─┐
  #    3     4
  assert nombre_feuilles((0,None,(1,(2,(3,None,None),(4,None,None)),None)))==2
  #           ┌──────────── 16 ──────────┐
  #    ┌───── 5 ─────┐             ┌──── 7 ─────┐
  # ┌─ 4 ──┐     ┌─ 10 ──┐      ┌─ 6 ─┐      ┌─ 1 ──┐
  # 2     11     8      14      3     9     15     12
  assert nombre_feuilles((16,(5,(4,(2,None,None),(11,None,None)),(10,(8,None,None),(14,None,None))),(7,(6,(3,None,None),(9,None,None)),(1,(15,None,None),(12,None,None)))))==8
  print('  OK')

def feuille_droite(arbre):
  ...

def test_feuille_droite():
  print('Test de la fonction feuille_droite')
  assert feuille_droite((5,None,None))==5
  assert feuille_droite((2,(6,None,None),None))==6
  assert feuille_droite((1,None,(4,None,None)))==4
  # ┌─ 0 ─┐
  # 2     7
  assert feuille_droite((0,(2,None,None),(7,None,None)))==7
  # 0 ──────────┐
  #       ┌──── 1
  #    ┌─ 2 ─┐
  #    3     4
  assert feuille_droite((0,None,(1,(2,(3,None,None),(4,None,None)),None)))==4
  #              ┌─ 0 
  #           ┌─ 2    
  #        ┌─ 3       
  #     ┌─ 7          
  #  ┌─ 1             
  #  4                
  assert feuille_droite((0,(2,(3,(7,(1,(4,None,None),None),None),None),None),None))==4
  #           ┌──────────── 16 ──────────┐
  #    ┌───── 5 ─────┐             ┌──── 7 ─────┐
  # ┌─ 4 ──┐     ┌─ 10 ──┐      ┌─ 6 ─┐      ┌─ 1 ──┐
  # 2     11     8      14      3     9     15     12
  assert feuille_droite((16,(5,(4,(2,None,None),(11,None,None)),(10,(8,None,None),(14,None,None))),(7,(6,(3,None,None),(9,None,None)),(1,(15,None,None),(12,None,None)))))==12
  print('  OK')

test_nombre_feuilles()
test_feuille_droite()
