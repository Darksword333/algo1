#!/usr/bin/python3

# la fonction retourne True si le chat attrape la souris, False sinon
def chat_attrape_souris(carte, saut):
    ...
       


# Tests de validation, ne pas modifier !
def test():
    assert chat_attrape_souris(['..C...s..'], 5) 
    assert chat_attrape_souris(['..s...C..'], 5) 
    assert not chat_attrape_souris(['..C...s..'], 2) 
    assert not chat_attrape_souris(['..s...C..'], 2) 
    assert chat_attrape_souris(['..C......', '.........', '....s....'], 5) 
    assert not chat_attrape_souris(['..C......', '.........', '....s....'], 3) 
    assert not chat_attrape_souris(['.C.......', '.........', '......s..'], 5) 
    assert not chat_attrape_souris(['..C......', '.........', '.........'], 5) # miaou !
    assert not chat_attrape_souris(['..s......', '.........', '.........'], 5) # miaou ?

    print("Bien joué !")


test()